Upload index.html and plumber-hero.svg. The styling is already inside index.html, so there is no separate styles.css needed.
